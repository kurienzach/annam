<div class="footer-1">
    <div class="container text-center">
        <ul class="copyright clearfix list-unstyled list-inline">
            <li><a href="#">About Us</a></li>
            <li><a href="#">Service Area</a></li>
            <li><a href="#">Careers</a></li>
            <li><a href="#">Faqs</a></li>
            <li><a href="#">Privacy & Terms</a></li>
            <li><a href="#">Large orders</a></li>
        </ul>
        <p class="lead">© 2015 <a href="index.html">annam homely food</a>. all rights reserved.</p>
    </div>
</div>